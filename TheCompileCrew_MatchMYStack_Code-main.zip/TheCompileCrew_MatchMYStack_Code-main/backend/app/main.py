# backend/app/main.py
from fastapi import FastAPI, Request, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import logging
import os

# Import routers
from app.api.routes import auth, users, resumes, projects, chat, oauth
from app.api.routes.match import router as match_router
from app.api.websocket import websocket_endpoint
from app.db.base import Base
from app.db.session import engine

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create DB tables
Base.metadata.create_all(bind=engine)

# Add missing columns if needed (migration)
from sqlalchemy import inspect, text

def migrate_database():
    """Add missing columns to existing tables and handle column renames"""
    try:
        inspector = inspect(engine)
        
        # Check users table
        if 'users' in inspector.get_table_names():
            columns = [col['name'] for col in inspector.get_columns('users')]
            
            # Handle email_verified -> is_verified migration
            if 'email_verified' in columns and 'is_verified' not in columns:
                with engine.begin() as conn:
                    # Add is_verified column
                    conn.execute(text("ALTER TABLE users ADD COLUMN is_verified BOOLEAN DEFAULT 0 NOT NULL"))
                    # Copy data from email_verified to is_verified
                    conn.execute(text("UPDATE users SET is_verified = email_verified"))
                logger.info("✅ Added is_verified column and migrated data from email_verified")
            elif 'is_verified' not in columns:
                # If neither exists, add is_verified
                with engine.begin() as conn:
                    conn.execute(text("ALTER TABLE users ADD COLUMN is_verified BOOLEAN DEFAULT 0 NOT NULL"))
                logger.info("✅ Added is_verified column to users table")
            
            # Add updated_at if missing
            if 'updated_at' not in columns:
                with engine.begin() as conn:
                    conn.execute(text("ALTER TABLE users ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"))
                logger.info("✅ Added updated_at column to users table")
            
            # Add google_id if missing
            if 'google_id' not in columns:
                with engine.begin() as conn:
                    conn.execute(text("ALTER TABLE users ADD COLUMN google_id TEXT"))
                logger.info("✅ Added google_id column to users table")
        
        logger.info("✅ Database migration completed successfully")
    except Exception as e:
        logger.error(f"❌ Database migration error: {e}")

# Run migration
migrate_database()

# Create FastAPI app
app = FastAPI(title="MatchMyStack - Backend API", version="1.0.0")

# ✅ UPDATED: CORS origins with 8080 as primary dev port
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:8080")
origins = [
    "http://localhost:8080",       # ✅ Primary dev frontend
    "http://127.0.0.1:8080",
    "http://localhost:5173",       # Alternate Vite port
    "http://127.0.0.1:5173",
    "http://localhost:8000",       # Backend dev
    "http://127.0.0.1:8000",
    FRONTEND_URL,                  # Production frontend URL from environment
]

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files for uploads
UPLOAD_DIR = Path(__file__).parent / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")
logger.info(f"✓ Static files mounted at /uploads → {UPLOAD_DIR}")

# Register routers
app.include_router(oauth.router, prefix="/auth", tags=["auth"])
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(resumes.router)
app.include_router(projects.router)
app.include_router(match_router)
app.include_router(chat.router)

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "MatchMyStack API",
        "version": "1.0.0",
        "status": "running"
    }

# Health check endpoint
@app.get("/ping")
async def ping(request: Request):
    """Lightweight health check endpoint"""
    return {
        "ok": True,
        "origin": request.headers.get("origin"),
        "service": "main"
    }

# WebSocket endpoint
@app.websocket("/ws/chat/{room_id}")
async def websocket_chat(websocket: WebSocket, room_id: int, token: str):
    await websocket_endpoint(websocket, room_id, token)

# Custom OpenAPI schema with JWT Bearer auth
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=app.title,
        version="1.0.0",
        description="MatchMyStack API",
        routes=app.routes,
    )

    # Add bearer auth scheme
    components = openapi_schema.setdefault("components", {})
    security_schemes = components.setdefault("securitySchemes", {})
    security_schemes["bearerAuth"] = {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT",
    }

    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi